#!/bin/sh
cd ~/tmpfs
flameshot "$@"
