#!/bin/sh

herbstclient move_index "$@"
herbstclient use_index "$@"
